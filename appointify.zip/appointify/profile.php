<?php
/**
 * Appointify - Patient Profile & Appointment History
 * View and manage patient appointments
 */
session_start();
require_once 'connection.php';

// Check if user is logged in as patient
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 3) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';

// Handle appointment cancellation
if (isset($_GET['cancel']) && isset($_GET['app_id'])) {
    $app_id = (int)$_GET['app_id'];
    try {
        $stmt = $pdo->prepare("UPDATE doctor_availablity SET status = 'cancelled' WHERE app_id = ? AND user_id = ?");
        $stmt->execute([$app_id, $user_id]);
        $message = 'Appointment cancelled successfully.';
    } catch (PDOException $e) {
        $message = 'Error: ' . $e->getMessage();
    }
}

// Get user info
try {
    $stmt = $pdo->prepare("SELECT * FROM info WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    // Get all appointments with doctor details
    $stmt = $pdo->prepare("
        SELECT da.*, d.Name as doctor_name, d.Speciality, d.Hospital, d.ChamberLocation
        FROM doctor_availablity da
        JOIN doctor d ON da.doc_id = d.IndexNumber
        WHERE da.user_id = ?
        ORDER BY da.date DESC, da.appointment_time DESC
    ");
    $stmt->execute([$user_id]);
    $appointments = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
}

include 'includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="page-container">
            <h2 class="mb-4"><i class="fas fa-user-circle"></i> My Profile</h2>
            
            <?php if ($message): ?>
                <div class="alert alert-info alert-dismissible fade show">
                    <i class="fas fa-info-circle"></i> <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- User Information -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5><i class="fas fa-user"></i> Personal Information</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Name:</strong> <?php echo htmlspecialchars($user['name']); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>User Type:</strong> Patient</p>
                            <p><strong>Member Since:</strong> <?php echo date('F Y', strtotime($user['created_at'])); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Appointments -->
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-calendar-alt"></i> My Appointments</h5>
                    <a href="search.php" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Book New Appointment
                    </a>
                </div>
                <div class="card-body">
                    <?php if (empty($appointments)): ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> You don't have any appointments yet. 
                            <a href="search.php">Book your first appointment</a>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Doctor</th>
                                        <th>Specialty</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Location</th>
                                        <th>Fee</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($appointments as $apt): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($apt['doctor_name']); ?></td>
                                            <td><?php echo htmlspecialchars($apt['Speciality']); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($apt['date'])); ?></td>
                                            <td><?php echo date('h:i A', strtotime($apt['appointment_time'])); ?></td>
                                            <td><?php echo htmlspecialchars($apt['ChamberLocation']); ?></td>
                                            <td>₹<?php echo htmlspecialchars($apt['cost']); ?></td>
                                            <td>
                                                <?php
                                                $status_class = '';
                                                switch($apt['status']) {
                                                    case 'approved':
                                                        $status_class = 'success';
                                                        break;
                                                    case 'pending':
                                                        $status_class = 'warning';
                                                        break;
                                                    case 'rejected':
                                                        $status_class = 'danger';
                                                        break;
                                                    case 'cancelled':
                                                        $status_class = 'secondary';
                                                        break;
                                                }
                                                ?>
                                                <span class="badge bg-<?php echo $status_class; ?>">
                                                    <?php echo ucfirst($apt['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($apt['status'] == 'pending' || $apt['status'] == 'approved'): ?>
                                                    <a href="?cancel=1&app_id=<?php echo $apt['app_id']; ?>" 
                                                       class="btn btn-danger btn-sm"
                                                       onclick="return confirm('Are you sure you want to cancel this appointment?')">
                                                        <i class="fas fa-times"></i> Cancel
                                                    </a>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
