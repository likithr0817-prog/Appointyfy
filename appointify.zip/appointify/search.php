<?php
/**
 * Appointify - Search Doctors Page
 * Search doctors by specialty and division
 */
session_start();
require_once 'connection.php';

// Get search parameters
$specialty = isset($_GET['specialty']) ? trim($_GET['specialty']) : '';
$division = isset($_GET['division']) ? trim($_GET['division']) : '';

// Build query
$query = "SELECT * FROM doctor WHERE approval_status = 'approved'";
$params = [];

if (!empty($specialty)) {
    $query .= " AND Speciality LIKE ?";
    $params[] = "%$specialty%";
}

if (!empty($division)) {
    $query .= " AND Division LIKE ?";
    $params[] = "%$division%";
}

$query .= " ORDER BY Name ASC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $doctors = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $doctors = [];
}

// Get all unique specialties and divisions for filters
try {
    $stmt = $pdo->query("SELECT DISTINCT Speciality FROM doctor WHERE approval_status = 'approved' AND Speciality IS NOT NULL ORDER BY Speciality");
    $specialties = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $stmt = $pdo->query("SELECT DISTINCT Division FROM doctor WHERE approval_status = 'approved' AND Division IS NOT NULL ORDER BY Division");
    $divisions = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $specialties = [];
    $divisions = [];
}

include 'includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="page-container">
            <h2 class="mb-4"><i class="fas fa-search"></i> Find a Doctor</h2>
            
            <!-- Search Form -->
            <div class="search-section mb-4">
                <form method="GET" action="">
                    <div class="row">
                        <div class="col-md-5 mb-3">
                            <label for="specialty" class="form-label">
                                <i class="fas fa-stethoscope"></i> Specialty
                            </label>
                            <select class="form-control" id="specialty" name="specialty">
                                <option value="">-- All Specialties --</option>
                                <?php foreach ($specialties as $spec): ?>
                                    <option value="<?php echo htmlspecialchars($spec); ?>" 
                                        <?php echo ($specialty == $spec) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($spec); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-5 mb-3">
                            <label for="division" class="form-label">
                                <i class="fas fa-map-marker-alt"></i> Location/Division
                            </label>
                            <select class="form-control" id="division" name="division">
                                <option value="">-- All Locations --</option>
                                <?php foreach ($divisions as $div): ?>
                                    <option value="<?php echo htmlspecialchars($div); ?>"
                                        <?php echo ($division == $div) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($div); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-2 mb-3">
                            <label class="form-label">&nbsp;</label>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search"></i> Search
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Search Results -->
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if (empty($doctors)): ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> No doctors found matching your criteria. Please try different filters.
                </div>
            <?php else: ?>
                <h4 class="mb-3">
                    <i class="fas fa-user-md"></i> 
                    Found <?php echo count($doctors); ?> Doctor<?php echo count($doctors) > 1 ? 's' : ''; ?>
                </h4>
                
                <div class="row">
                    <?php foreach ($doctors as $doctor): ?>
                        <div class="col-md-6 mb-4">
                            <div class="card doctor-card">
                                <div class="card-body">
                                    <div class="doctor-info">
                                        <div class="doctor-avatar">
                                            <?php echo strtoupper(substr($doctor['Name'], 0, 1)); ?>
                                        </div>
                                        <div class="doctor-details flex-grow-1">
                                            <h5><?php echo htmlspecialchars($doctor['Name']); ?></h5>
                                            <p class="mb-1">
                                                <i class="fas fa-graduation-cap text-primary"></i>
                                                <strong><?php echo htmlspecialchars($doctor['Degree'] ?? 'N/A'); ?></strong>
                                            </p>
                                            <p class="mb-1">
                                                <i class="fas fa-stethoscope text-success"></i>
                                                <?php echo htmlspecialchars($doctor['Speciality'] ?? 'N/A'); ?>
                                            </p>
                                            <p class="mb-1">
                                                <i class="fas fa-hospital text-danger"></i>
                                                <?php echo htmlspecialchars($doctor['Hospital'] ?? 'N/A'); ?>
                                            </p>
                                            <p class="mb-1">
                                                <i class="fas fa-map-marker-alt text-info"></i>
                                                <?php echo htmlspecialchars($doctor['Division'] ?? 'N/A'); ?>
                                            </p>
                                            <p class="mb-1">
                                                <i class="fas fa-clock text-warning"></i>
                                                <?php 
                                                if ($doctor['TimeStart'] && $doctor['TimeEnd']) {
                                                    echo date('h:i A', strtotime($doctor['TimeStart'])) . ' - ' . 
                                                         date('h:i A', strtotime($doctor['TimeEnd']));
                                                } else {
                                                    echo 'Not specified';
                                                }
                                                ?>
                                            </p>
                                            <p class="mb-2">
                                                <i class="fas fa-rupee-sign text-success"></i>
                                                <strong>₹<?php echo htmlspecialchars($doctor['VisitCharge'] ?? '0'); ?></strong> per visit
                                            </p>
                                            <a href="appointment.php?doctor_id=<?php echo $doctor['IndexNumber']; ?>" 
                                               class="btn btn-primary btn-sm">
                                                <i class="fas fa-calendar-plus"></i> Book Appointment
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
