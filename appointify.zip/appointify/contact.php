<?php
/**
 * Appointify - Contact Page
 * Contact information and form
 */
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $subject = htmlspecialchars(trim($_POST['subject']));
    $msg = htmlspecialchars(trim($_POST['message']));
    
    // In a real application, you would send an email or store in database
    $message = 'Thank you for contacting us! We will get back to you soon.';
}

include 'includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="page-container">
            <h2 class="text-center mb-4"><i class="fas fa-envelope"></i> Contact Us</h2>
            
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <div class="row">
                <!-- Contact Form -->
                <div class="col-md-7 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-paper-plane"></i> Send us a Message</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="mb-3">
                                    <label for="name" class="form-label">
                                        <i class="fas fa-user"></i> Your Name
                                    </label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email" class="form-label">
                                        <i class="fas fa-envelope"></i> Your Email
                                    </label>
                                    <input type="email" class="form-control" id="email" name="email" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="subject" class="form-label">
                                        <i class="fas fa-tag"></i> Subject
                                    </label>
                                    <input type="text" class="form-control" id="subject" name="subject" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="message" class="form-label">
                                        <i class="fas fa-comment"></i> Message
                                    </label>
                                    <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane"></i> Send Message
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Contact Information -->
                <div class="col-md-5 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-info-circle"></i> Contact Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-4">
                                <h6><i class="fas fa-map-marker-alt text-danger"></i> Address</h6>
                                <p>
                                    Appointify Healthcare Solutions<br>
                                    123 Medical Plaza, 2nd Floor<br>
                                    MG Road, Bangalore - 560001<br>
                                    Karnataka, India
                                </p>
                            </div>
                            
                            <div class="mb-4">
                                <h6><i class="fas fa-phone text-success"></i> Phone</h6>
                                <p>
                                    Support: +91 80 1234 5678<br>
                                    Emergency: +91 98765 43210
                                </p>
                            </div>
                            
                            <div class="mb-4">
                                <h6><i class="fas fa-envelope text-primary"></i> Email</h6>
                                <p>
                                    General: info@appointify.com<br>
                                    Support: support@appointify.com<br>
                                    Admin: admin@appointify.com
                                </p>
                            </div>
                            
                            <div class="mb-4">
                                <h6><i class="fas fa-clock text-warning"></i> Working Hours</h6>
                                <p>
                                    Monday - Friday: 9:00 AM - 6:00 PM<br>
                                    Saturday: 9:00 AM - 2:00 PM<br>
                                    Sunday: Closed
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card mt-4">
                        <div class="card-header">
                            <h5><i class="fas fa-share-alt"></i> Follow Us</h5>
                        </div>
                        <div class="card-body text-center">
                            <a href="#" class="btn btn-primary btn-lg m-2">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="#" class="btn btn-info btn-lg m-2">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a href="#" class="btn btn-danger btn-lg m-2">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a href="#" class="btn btn-success btn-lg m-2">
                                <i class="fab fa-whatsapp"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- FAQ Section -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5><i class="fas fa-question-circle"></i> Frequently Asked Questions</h5>
                </div>
                <div class="card-body">
                    <div class="accordion" id="faqAccordion">
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                    How do I book an appointment?
                                </button>
                            </h2>
                            <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Register or login to your account, search for a doctor by specialty or location, 
                                    view their profile and availability, then click "Book Appointment" to schedule your visit.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                    Can I cancel my appointment?
                                </button>
                            </h2>
                            <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Yes, you can cancel your appointment from your profile page. Please cancel at least 
                                    24 hours in advance to allow others to book that slot.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                    How do doctors join the platform?
                                </button>
                            </h2>
                            <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Doctors can register by selecting "Doctor" during registration. After submitting their 
                                    profile, an admin will review and approve the registration. Once approved, they can 
                                    start receiving appointments.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                                    Is my data secure?
                                </button>
                            </h2>
                            <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Absolutely! We use secure encryption and follow industry best practices to protect 
                                    your personal and medical information. We never share your data with third parties 
                                    without your consent.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
