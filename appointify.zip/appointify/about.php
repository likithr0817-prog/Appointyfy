<?php
/**
 * Appointify - About Page
 * Information about the system
 */
include 'includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="page-container">
            <h2 class="text-center mb-4"><i class="fas fa-info-circle"></i> About Appointify</h2>
            
            <div class="row mb-5">
                <div class="col-md-6">
                    <h4><i class="fas fa-bullseye"></i> Our Mission</h4>
                    <p>
                        Appointify is dedicated to bridging the gap between patients and healthcare providers 
                        by providing a simple, efficient, and user-friendly platform for booking medical appointments. 
                        Our goal is to make quality healthcare accessible to everyone.
                    </p>
                </div>
                <div class="col-md-6">
                    <h4><i class="fas fa-eye"></i> Our Vision</h4>
                    <p>
                        To become the leading healthcare appointment management system, empowering patients 
                        to take control of their health journey while helping doctors manage their practice 
                        more efficiently.
                    </p>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5><i class="fas fa-star"></i> Key Features</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <h6><i class="fas fa-check-circle text-success"></i> For Patients</h6>
                            <ul>
                                <li>Easy doctor search by specialty and location</li>
                                <li>View doctor profiles and availability</li>
                                <li>Quick and simple appointment booking</li>
                                <li>Manage appointment history</li>
                                <li>Cancel appointments when needed</li>
                            </ul>
                        </div>
                        <div class="col-md-6 mb-3">
                            <h6><i class="fas fa-check-circle text-primary"></i> For Doctors</h6>
                            <ul>
                                <li>Professional profile management</li>
                                <li>Set availability and working hours</li>
                                <li>Approve/reject appointment requests</li>
                                <li>View appointment schedule</li>
                                <li>Track patient appointments</li>
                            </ul>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <h6><i class="fas fa-check-circle text-warning"></i> For Administrators</h6>
                            <ul>
                                <li>Complete system oversight and management</li>
                                <li>Approve/reject doctor registrations</li>
                                <li>Manage users and doctors</li>
                                <li>Monitor all appointments</li>
                                <li>System-wide analytics and reporting</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5><i class="fas fa-shield-alt"></i> Security & Privacy</h5>
                </div>
                <div class="card-body">
                    <p>
                        We take your privacy and security seriously. All user data is stored securely using 
                        industry-standard encryption. We never share your personal information with third parties 
                        without your explicit consent.
                    </p>
                    <ul>
                        <li>Secure user authentication</li>
                        <li>Role-based access control</li>
                        <li>Protected database connections</li>
                        <li>Regular security updates</li>
                    </ul>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5><i class="fas fa-code"></i> Technology Stack</h5>
                </div>
                <div class="card-body">
                    <p>Appointify is built using modern, reliable technologies:</p>
                    <div class="row">
                        <div class="col-md-6">
                            <ul>
                                <li><strong>Frontend:</strong> HTML5, CSS3, JavaScript, Bootstrap 5</li>
                                <li><strong>Backend:</strong> PHP 7.4+ with PDO</li>
                                <li><strong>Database:</strong> MySQL 5.7+</li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <ul>
                                <li><strong>Server:</strong> Apache (XAMPP)</li>
                                <li><strong>Architecture:</strong> 3-Tier (Presentation, Application, Data)</li>
                                <li><strong>Icons:</strong> Font Awesome 6</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-5">
                <h4>Ready to Get Started?</h4>
                <p class="mb-4">Join thousands of satisfied patients and healthcare providers today!</p>
                <a href="register.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-user-plus"></i> Register Now
                </a>
                <a href="contact.php" class="btn btn-outline-primary btn-lg ms-2">
                    <i class="fas fa-envelope"></i> Contact Us
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
