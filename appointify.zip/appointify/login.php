<?php
/**
 * Appointify - Login Page
 * User authentication for all user types
 */
session_start();
require_once 'connection.php';

$error = '';
$success = '';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    $user_type = $_SESSION['user_type'];
    if ($user_type == 1) {
        header('Location: admin/admin_dashboard.php');
    } elseif ($user_type == 2) {
        header('Location: doctor_dashboard.php');
    } else {
        header('Location: profile.php');
    }
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    
    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields';
    } else {
        try {
            // Check in info table first
            $stmt = $pdo->prepare("SELECT * FROM info WHERE email = ? AND pass = ?");
            $stmt->execute([$email, $password]);
            $user = $stmt->fetch();
            
            if ($user) {
                // Set session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_type'] = $user['user_type'];
                
                // Redirect based on user type
                if ($user['user_type'] == 1) {
                    header('Location: admin/admin_dashboard.php');
                } elseif ($user['user_type'] == 2) {
                    header('Location: doctor_dashboard.php');
                } else {
                    header('Location: profile.php');
                }
                exit();
            } else {
                $error = 'Invalid email or password';
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

include 'includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="form-container">
            <h2 class="text-center mb-4"><i class="fas fa-sign-in-alt"></i> Login to Appointify</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['registered'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> Registration successful! Please login.
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['logout'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> You have been logged out successfully.
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="email" class="form-label">
                        <i class="fas fa-envelope"></i> Email Address
                    </label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                
                <div class="mb-3">
                    <label for="password" class="form-label">
                        <i class="fas fa-lock"></i> Password
                    </label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                
                <button type="submit" class="btn btn-primary w-100 mb-3">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
            </form>
            
            <div class="text-center">
                <p>Don't have an account? <a href="register.php">Register here</a></p>
            </div>
            
            <hr>
            
            <div class="text-center">
                <h6 class="text-muted">Default Admin Credentials:</h6>
                <p class="mb-1"><strong>Email:</strong> admin@appointify.com</p>
                <p><strong>Password:</strong> admin123</p>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
