<?php
/**
 * Appointify - Registration Page
 * User registration for Doctors and Patients
 */
session_start();
require_once 'connection.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $user_type = (int)$_POST['user_type']; // 2 for Doctor, 3 for Patient
    
    // Validation
    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = 'Please fill in all fields';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long';
    } else {
        try {
            // Check if email already exists
            $stmt = $pdo->prepare("SELECT id FROM info WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = 'Email already registered';
            } else {
                // Insert into info table
                $stmt = $pdo->prepare("INSERT INTO info (name, email, pass, user_type) VALUES (?, ?, ?, ?)");
                $stmt->execute([$name, $email, $password, $user_type]);
                
                // If doctor, create entry in doctor table with pending status
                if ($user_type == 2) {
                    $stmt = $pdo->prepare("INSERT INTO doctor (Name, Email, Password, approval_status) VALUES (?, ?, ?, 'pending')");
                    $stmt->execute([$name, $email, $password]);
                    $success = 'Doctor registration submitted! Please wait for admin approval.';
                } else {
                    $success = 'Registration successful! Please login.';
                }
                
                // Redirect to login page after 2 seconds
                header('refresh:2;url=login.php?registered=1');
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

include 'includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="form-container" style="max-width: 600px;">
            <h2 class="text-center mb-4"><i class="fas fa-user-plus"></i> Register with Appointify</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="user_type" class="form-label">
                        <i class="fas fa-user-tag"></i> Register As
                    </label>
                    <select class="form-control" id="user_type" name="user_type" required>
                        <option value="">-- Select Type --</option>
                        <option value="3">Patient</option>
                        <option value="2">Doctor</option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label for="name" class="form-label">
                        <i class="fas fa-user"></i> Full Name
                    </label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                
                <div class="mb-3">
                    <label for="email" class="form-label">
                        <i class="fas fa-envelope"></i> Email Address
                    </label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                
                <div class="mb-3">
                    <label for="password" class="form-label">
                        <i class="fas fa-lock"></i> Password
                    </label>
                    <input type="password" class="form-control" id="password" name="password" required minlength="6">
                    <small class="text-muted">Minimum 6 characters</small>
                </div>
                
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">
                        <i class="fas fa-lock"></i> Confirm Password
                    </label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                </div>
                
                <button type="submit" class="btn btn-primary w-100 mb-3">
                    <i class="fas fa-user-plus"></i> Register
                </button>
            </form>
            
            <div class="text-center">
                <p>Already have an account? <a href="login.php">Login here</a></p>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
