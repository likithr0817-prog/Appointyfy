<?php
/**
 * Appointify - Home Page
 * Landing page with hero section and features
 */
include 'includes/navbar.php';
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="hero-content">
        <h1><i class="fas fa-heartbeat"></i> Welcome to Appointify</h1>
        <p>Your trusted platform to find and book appointments with qualified doctors instantly</p>
        <p>Quality healthcare at your fingertips - Anytime, Anywhere</p>
        <div class="mt-4">
            <?php if (!$is_logged_in): ?>
                <a href="search.php" class="btn btn-primary btn-hero">
                    <i class="fas fa-search"></i> Find a Doctor
                </a>
                <a href="register.php" class="btn btn-outline-light btn-hero ms-3">
                    <i class="fas fa-user-plus"></i> Register Now
                </a>
            <?php else: ?>
                <a href="search.php" class="btn btn-primary btn-hero">
                    <i class="fas fa-search"></i> Book an Appointment
                </a>
                <a href="profile.php" class="btn btn-outline-light btn-hero ms-3">
                    <i class="fas fa-user-circle"></i> My Profile
                </a>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="container my-5">
    <div class="row text-center">
        <div class="col-md-4 mb-4 fade-in">
            <div class="card h-100">
                <div class="card-body">
                    <div class="mb-3">
                        <i class="fas fa-user-md fa-4x text-primary"></i>
                    </div>
                    <h4>Find Qualified Doctors</h4>
                    <p>Search from our extensive database of experienced and qualified doctors across various specialties.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4 fade-in">
            <div class="card h-100">
                <div class="card-body">
                    <div class="mb-3">
                        <i class="fas fa-calendar-check fa-4x text-success"></i>
                    </div>
                    <h4>Easy Booking</h4>
                    <p>Book appointments with just a few clicks. View doctor availability and choose your preferred time slot.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4 fade-in">
            <div class="card h-100">
                <div class="card-body">
                    <div class="mb-3">
                        <i class="fas fa-clock fa-4x text-info"></i>
                    </div>
                    <h4>24/7 Access</h4>
                    <p>Access our platform anytime, anywhere. Manage your appointments and health records on the go.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- How It Works Section -->
<section class="container my-5">
    <div class="page-container">
        <h2 class="text-center mb-4"><i class="fas fa-question-circle"></i> How It Works</h2>
        <div class="row">
            <div class="col-md-3 text-center mb-4">
                <div class="mb-3">
                    <div class="rounded-circle bg-primary text-white mx-auto" style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                        <h2 class="mb-0">1</h2>
                    </div>
                </div>
                <h5>Register/Login</h5>
                <p>Create your account or login to get started</p>
            </div>
            <div class="col-md-3 text-center mb-4">
                <div class="mb-3">
                    <div class="rounded-circle bg-success text-white mx-auto" style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                        <h2 class="mb-0">2</h2>
                    </div>
                </div>
                <h5>Search Doctors</h5>
                <p>Find doctors by specialty or location</p>
            </div>
            <div class="col-md-3 text-center mb-4">
                <div class="mb-3">
                    <div class="rounded-circle bg-info text-white mx-auto" style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                        <h2 class="mb-0">3</h2>
                    </div>
                </div>
                <h5>Book Appointment</h5>
                <p>Choose your preferred date and time</p>
            </div>
            <div class="col-md-3 text-center mb-4">
                <div class="mb-3">
                    <div class="rounded-circle bg-warning text-white mx-auto" style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                        <h2 class="mb-0">4</h2>
                    </div>
                </div>
                <h5>Get Confirmation</h5>
                <p>Receive confirmation and visit doctor</p>
            </div>
        </div>
    </div>
</section>

<!-- Specialties Section -->
<section class="container my-5">
    <h2 class="text-center mb-4"><i class="fas fa-stethoscope"></i> Popular Specialties</h2>
    <div class="row">
        <?php
        $specialties = [
            ['name' => 'Cardiologist', 'icon' => 'fa-heartbeat', 'color' => 'danger'],
            ['name' => 'Dermatologist', 'icon' => 'fa-hand-sparkles', 'color' => 'warning'],
            ['name' => 'Orthopedic', 'icon' => 'fa-bone', 'color' => 'info'],
            ['name' => 'Pediatrician', 'icon' => 'fa-baby', 'color' => 'success'],
            ['name' => 'Dentist', 'icon' => 'fa-tooth', 'color' => 'primary'],
            ['name' => 'Neurologist', 'icon' => 'fa-brain', 'color' => 'secondary']
        ];
        
        foreach ($specialties as $specialty):
        ?>
        <div class="col-md-4 col-lg-2 mb-3">
            <a href="search.php?specialty=<?php echo urlencode($specialty['name']); ?>" class="text-decoration-none">
                <div class="card text-center h-100 specialty-card">
                    <div class="card-body">
                        <i class="fas <?php echo $specialty['icon']; ?> fa-3x text-<?php echo $specialty['color']; ?> mb-2"></i>
                        <h6><?php echo $specialty['name']; ?></h6>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- Footer -->
<footer class="footer text-center">
    <div class="container">
        <p class="mb-2">&copy; 2026 Appointify. All rights reserved.</p>
        <p>
            <a href="about.php">About</a> | 
            <a href="contact.php">Contact</a> | 
            <a href="#">Privacy Policy</a> | 
            <a href="#">Terms of Service</a>
        </p>
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
