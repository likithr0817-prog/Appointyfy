<?php
/**
 * Appointify - Doctor Dashboard
 * Doctor's overview and statistics
 */
session_start();
require_once 'connection.php';

// Check if user is logged in as doctor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 2) {
    header('Location: login.php');
    exit();
}

// Get doctor info from email
$email = $_SESSION['user_email'];

try {
    $stmt = $pdo->prepare("SELECT * FROM doctor WHERE Email = ?");
    $stmt->execute([$email]);
    $doctor = $stmt->fetch();
    
    if (!$doctor) {
        header('Location: logout.php');
        exit();
    }
    
    $doctor_id = $doctor['IndexNumber'];
    
    // Get statistics
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM doctor_availablity WHERE doc_id = ?");
    $stmt->execute([$doctor_id]);
    $total_appointments = $stmt->fetch()['total'];
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM doctor_availablity WHERE doc_id = ? AND status = 'pending'");
    $stmt->execute([$doctor_id]);
    $pending_appointments = $stmt->fetch()['total'];
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM doctor_availablity WHERE doc_id = ? AND status = 'approved'");
    $stmt->execute([$doctor_id]);
    $approved_appointments = $stmt->fetch()['total'];
    
    // Get today's appointments
    $stmt = $pdo->prepare("
        SELECT da.*, u.name as patient_name, u.email as patient_email
        FROM doctor_availablity da
        JOIN info u ON da.user_id = u.id
        WHERE da.doc_id = ? AND da.date = CURDATE()
        ORDER BY da.appointment_time ASC
    ");
    $stmt->execute([$doctor_id]);
    $today_appointments = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
}

include 'includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="page-container">
            <h2 class="mb-4">
                <i class="fas fa-tachometer-alt"></i> Doctor Dashboard
            </h2>
            
            <?php if ($doctor['approval_status'] != 'approved'): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Account Status: <?php echo ucfirst($doctor['approval_status']); ?></strong><br>
                    <?php if ($doctor['approval_status'] == 'pending'): ?>
                        Your account is pending admin approval. You will be able to receive appointments once approved.
                    <?php else: ?>
                        Your account has been rejected by admin. Please contact support.
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <!-- Statistics Cards -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="card text-white bg-info">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0"><?php echo $total_appointments; ?></h3>
                                    <p class="mb-0">Total Appointments</p>
                                </div>
                                <i class="fas fa-calendar fa-3x opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-3">
                    <div class="card text-white bg-warning">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0"><?php echo $pending_appointments; ?></h3>
                                    <p class="mb-0">Pending Review</p>
                                </div>
                                <i class="fas fa-clock fa-3x opacity-50"></i>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent">
                            <a href="doctor_appointments.php?filter=pending" class="text-white text-decoration-none">
                                Review Now <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-3">
                    <div class="card text-white bg-success">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0"><?php echo $approved_appointments; ?></h3>
                                    <p class="mb-0">Confirmed</p>
                                </div>
                                <i class="fas fa-check-circle fa-3x opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Today's Appointments -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5><i class="fas fa-calendar-day"></i> Today's Appointments</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($today_appointments)): ?>
                        <p class="text-muted">No appointments scheduled for today.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Patient Name</th>
                                        <th>Contact</th>
                                        <th>Fee</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($today_appointments as $apt): ?>
                                        <tr>
                                            <td><?php echo date('h:i A', strtotime($apt['appointment_time'])); ?></td>
                                            <td><?php echo htmlspecialchars($apt['patient_name']); ?></td>
                                            <td><?php echo htmlspecialchars($apt['patient_email']); ?></td>
                                            <td>₹<?php echo $apt['cost']; ?></td>
                                            <td>
                                                <?php
                                                $badge = '';
                                                switch($apt['status']) {
                                                    case 'approved': $badge = 'success'; break;
                                                    case 'pending': $badge = 'warning'; break;
                                                    case 'rejected': $badge = 'danger'; break;
                                                    case 'cancelled': $badge = 'secondary'; break;
                                                }
                                                ?>
                                                <span class="badge bg-<?php echo $badge; ?>">
                                                    <?php echo ucfirst($apt['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="row">
                <div class="col-md-6 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-user-circle fa-3x text-primary mb-3"></i>
                            <h5>Update Profile</h5>
                            <p class="text-muted">Update your professional information and availability</p>
                            <a href="doctor_profile.php" class="btn btn-primary">
                                <i class="fas fa-edit"></i> Edit Profile
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-calendar-alt fa-3x text-success mb-3"></i>
                            <h5>Manage Appointments</h5>
                            <p class="text-muted">View and manage your appointment schedule</p>
                            <a href="doctor_appointments.php" class="btn btn-success">
                                <i class="fas fa-calendar-check"></i> View Appointments
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
