<?php
/**
 * Appointify - Admin Dashboard
 * Overview of system statistics
 */
session_start();
require_once '../connection.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 1) {
    header('Location: ../login.php');
    exit();
}

// Get statistics
try {
    // Total doctors
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM doctor");
    $total_doctors = $stmt->fetch()['total'];
    
    // Pending doctors
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM doctor WHERE approval_status = 'pending'");
    $pending_doctors = $stmt->fetch()['total'];
    
    // Total patients
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM info WHERE user_type = 3");
    $total_patients = $stmt->fetch()['total'];
    
    // Total appointments
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM doctor_availablity");
    $total_appointments = $stmt->fetch()['total'];
    
    // Pending appointments
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM doctor_availablity WHERE status = 'pending'");
    $pending_appointments = $stmt->fetch()['total'];
    
    // Recent appointments
    $stmt = $pdo->query("
        SELECT da.*, d.Name as doctor_name, u.name as patient_name
        FROM doctor_availablity da
        JOIN doctor d ON da.doc_id = d.IndexNumber
        JOIN info u ON da.user_id = u.id
        ORDER BY da.created_at DESC
        LIMIT 5
    ");
    $recent_appointments = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
}

$_SESSION['user_name'] = 'Admin';
include '../includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="page-container">
            <h2 class="mb-4"><i class="fas fa-tachometer-alt"></i> Admin Dashboard</h2>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <!-- Statistics Cards -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="card text-white bg-primary">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0"><?php echo $total_doctors; ?></h3>
                                    <p class="mb-0">Total Doctors</p>
                                </div>
                                <i class="fas fa-user-md fa-3x opacity-50"></i>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent">
                            <a href="admin_manage_doctors.php" class="text-white text-decoration-none">
                                View Details <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 mb-3">
                    <div class="card text-white bg-warning">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0"><?php echo $pending_doctors; ?></h3>
                                    <p class="mb-0">Pending Doctors</p>
                                </div>
                                <i class="fas fa-clock fa-3x opacity-50"></i>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent">
                            <a href="admin_manage_doctors.php?filter=pending" class="text-white text-decoration-none">
                                Review Now <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 mb-3">
                    <div class="card text-white bg-success">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0"><?php echo $total_patients; ?></h3>
                                    <p class="mb-0">Total Patients</p>
                                </div>
                                <i class="fas fa-users fa-3x opacity-50"></i>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent">
                            <a href="admin_manage_users.php" class="text-white text-decoration-none">
                                View Details <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 mb-3">
                    <div class="card text-white bg-info">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0"><?php echo $total_appointments; ?></h3>
                                    <p class="mb-0">Total Appointments</p>
                                </div>
                                <i class="fas fa-calendar-check fa-3x opacity-50"></i>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent">
                            <a href="admin_manage_appointments.php" class="text-white text-decoration-none">
                                View Details <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Appointments -->
            <div class="card">
                <div class="card-header">
                    <h5><i class="fas fa-calendar-alt"></i> Recent Appointments</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($recent_appointments)): ?>
                        <p class="text-muted">No appointments yet.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Patient</th>
                                        <th>Doctor</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Status</th>
                                        <th>Cost</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_appointments as $apt): ?>
                                        <tr>
                                            <td><?php echo $apt['app_id']; ?></td>
                                            <td><?php echo htmlspecialchars($apt['patient_name']); ?></td>
                                            <td><?php echo htmlspecialchars($apt['doctor_name']); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($apt['date'])); ?></td>
                                            <td><?php echo date('h:i A', strtotime($apt['appointment_time'])); ?></td>
                                            <td>
                                                <?php
                                                $badge = '';
                                                switch($apt['status']) {
                                                    case 'approved': $badge = 'success'; break;
                                                    case 'pending': $badge = 'warning'; break;
                                                    case 'rejected': $badge = 'danger'; break;
                                                    case 'cancelled': $badge = 'secondary'; break;
                                                }
                                                ?>
                                                <span class="badge bg-<?php echo $badge; ?>">
                                                    <?php echo ucfirst($apt['status']); ?>
                                                </span>
                                            </td>
                                            <td>₹<?php echo $apt['cost']; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
