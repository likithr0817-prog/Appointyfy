<?php
/**
 * Appointify - Admin Manage Doctors
 * Approve/reject/delete doctor registrations
 */
session_start();
require_once '../connection.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 1) {
    header('Location: ../login.php');
    exit();
}

$message = '';
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

// Handle actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $doctor_id = (int)$_GET['id'];
    $action = $_GET['action'];
    
    try {
        if ($action == 'approve') {
            $stmt = $pdo->prepare("UPDATE doctor SET approval_status = 'approved' WHERE IndexNumber = ?");
            $stmt->execute([$doctor_id]);
            $message = 'Doctor approved successfully!';
        } elseif ($action == 'reject') {
            $stmt = $pdo->prepare("UPDATE doctor SET approval_status = 'rejected' WHERE IndexNumber = ?");
            $stmt->execute([$doctor_id]);
            $message = 'Doctor rejected.';
        } elseif ($action == 'delete') {
            // Delete from doctor table (will cascade to appointments)
            $stmt = $pdo->prepare("DELETE FROM doctor WHERE IndexNumber = ?");
            $stmt->execute([$doctor_id]);
            
            // Also delete from info table if exists
            $stmt = $pdo->prepare("SELECT Email FROM doctor WHERE IndexNumber = ?");
            $stmt->execute([$doctor_id]);
            $doctor = $stmt->fetch();
            if ($doctor) {
                $stmt = $pdo->prepare("DELETE FROM info WHERE email = ? AND user_type = 2");
                $stmt->execute([$doctor['Email']]);
            }
            
            $message = 'Doctor deleted successfully!';
        }
    } catch (PDOException $e) {
        $message = 'Error: ' . $e->getMessage();
    }
}

// Get doctors based on filter
try {
    if ($filter == 'pending') {
        $stmt = $pdo->query("SELECT * FROM doctor WHERE approval_status = 'pending' ORDER BY created_at DESC");
    } elseif ($filter == 'approved') {
        $stmt = $pdo->query("SELECT * FROM doctor WHERE approval_status = 'approved' ORDER BY Name ASC");
    } elseif ($filter == 'rejected') {
        $stmt = $pdo->query("SELECT * FROM doctor WHERE approval_status = 'rejected' ORDER BY created_at DESC");
    } else {
        $stmt = $pdo->query("SELECT * FROM doctor ORDER BY created_at DESC");
    }
    $doctors = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $doctors = [];
}

$_SESSION['user_name'] = 'Admin';
include '../includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="page-container">
            <h2 class="mb-4"><i class="fas fa-user-md"></i> Manage Doctors</h2>
            
            <?php if ($message): ?>
                <div class="alert alert-info alert-dismissible fade show">
                    <i class="fas fa-info-circle"></i> <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Filter Buttons -->
            <div class="mb-4">
                <div class="btn-group" role="group">
                    <a href="?filter=all" class="btn <?php echo $filter == 'all' ? 'btn-primary' : 'btn-outline-primary'; ?>">
                        All Doctors
                    </a>
                    <a href="?filter=pending" class="btn <?php echo $filter == 'pending' ? 'btn-warning' : 'btn-outline-warning'; ?>">
                        Pending
                    </a>
                    <a href="?filter=approved" class="btn <?php echo $filter == 'approved' ? 'btn-success' : 'btn-outline-success'; ?>">
                        Approved
                    </a>
                    <a href="?filter=rejected" class="btn <?php echo $filter == 'rejected' ? 'btn-danger' : 'btn-outline-danger'; ?>">
                        Rejected
                    </a>
                </div>
            </div>
            
            <!-- Doctors Table -->
            <div class="card">
                <div class="card-header">
                    <h5>
                        <i class="fas fa-list"></i> 
                        <?php 
                        echo ucfirst($filter) . ' Doctors '; 
                        echo '(' . count($doctors) . ')';
                        ?>
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (empty($doctors)): ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> No doctors found in this category.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Degree</th>
                                        <th>Specialty</th>
                                        <th>Hospital</th>
                                        <th>Division</th>
                                        <th>Fee</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($doctors as $doctor): ?>
                                        <tr>
                                            <td><?php echo $doctor['IndexNumber']; ?></td>
                                            <td><?php echo htmlspecialchars($doctor['Name']); ?></td>
                                            <td><?php echo htmlspecialchars($doctor['Email']); ?></td>
                                            <td><?php echo htmlspecialchars($doctor['Degree'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($doctor['Speciality'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($doctor['Hospital'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($doctor['Division'] ?? 'N/A'); ?></td>
                                            <td>₹<?php echo htmlspecialchars($doctor['VisitCharge'] ?? '0'); ?></td>
                                            <td>
                                                <?php
                                                $badge = '';
                                                switch($doctor['approval_status']) {
                                                    case 'approved': $badge = 'success'; break;
                                                    case 'pending': $badge = 'warning'; break;
                                                    case 'rejected': $badge = 'danger'; break;
                                                }
                                                ?>
                                                <span class="badge bg-<?php echo $badge; ?>">
                                                    <?php echo ucfirst($doctor['approval_status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($doctor['approval_status'] == 'pending'): ?>
                                                    <a href="?action=approve&id=<?php echo $doctor['IndexNumber']; ?>&filter=<?php echo $filter; ?>" 
                                                       class="btn btn-success btn-sm"
                                                       onclick="return confirm('Approve this doctor?')">
                                                        <i class="fas fa-check"></i>
                                                    </a>
                                                    <a href="?action=reject&id=<?php echo $doctor['IndexNumber']; ?>&filter=<?php echo $filter; ?>" 
                                                       class="btn btn-danger btn-sm"
                                                       onclick="return confirm('Reject this doctor?')">
                                                        <i class="fas fa-times"></i>
                                                    </a>
                                                <?php elseif ($doctor['approval_status'] == 'rejected'): ?>
                                                    <a href="?action=approve&id=<?php echo $doctor['IndexNumber']; ?>&filter=<?php echo $filter; ?>" 
                                                       class="btn btn-success btn-sm"
                                                       onclick="return confirm('Approve this doctor?')">
                                                        <i class="fas fa-check"></i> Approve
                                                    </a>
                                                <?php endif; ?>
                                                
                                                <a href="?action=delete&id=<?php echo $doctor['IndexNumber']; ?>&filter=<?php echo $filter; ?>" 
                                                   class="btn btn-danger btn-sm"
                                                   onclick="return confirm('Are you sure you want to DELETE this doctor permanently? This will also delete all their appointments.')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
