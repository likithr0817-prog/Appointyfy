<?php
/**
 * Appointify - Doctor Appointments Management
 * View and manage appointments
 */
session_start();
require_once 'connection.php';

// Check if user is logged in as doctor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 2) {
    header('Location: login.php');
    exit();
}

$email = $_SESSION['user_email'];
$message = '';
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

// Get doctor info
try {
    $stmt = $pdo->prepare("SELECT * FROM doctor WHERE Email = ?");
    $stmt->execute([$email]);
    $doctor = $stmt->fetch();
    
    if (!$doctor) {
        header('Location: logout.php');
        exit();
    }
    
    $doctor_id = $doctor['IndexNumber'];
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
}

// Handle appointment actions
if (isset($_GET['action']) && isset($_GET['app_id'])) {
    $app_id = (int)$_GET['app_id'];
    $action = $_GET['action'];
    
    try {
        if ($action == 'approve') {
            $stmt = $pdo->prepare("UPDATE doctor_availablity SET status = 'approved' WHERE app_id = ? AND doc_id = ?");
            $stmt->execute([$app_id, $doctor_id]);
            $message = 'Appointment approved successfully!';
        } elseif ($action == 'reject') {
            $stmt = $pdo->prepare("UPDATE doctor_availablity SET status = 'rejected' WHERE app_id = ? AND doc_id = ?");
            $stmt->execute([$app_id, $doctor_id]);
            $message = 'Appointment rejected.';
        }
    } catch (PDOException $e) {
        $message = 'Error: ' . $e->getMessage();
    }
}

// Get appointments based on filter
try {
    $query = "
        SELECT da.*, u.name as patient_name, u.email as patient_email
        FROM doctor_availablity da
        JOIN info u ON da.user_id = u.id
        WHERE da.doc_id = ?
    ";
    
    $params = [$doctor_id];
    
    if ($filter != 'all') {
        $query .= " AND da.status = ?";
        $params[] = $filter;
    }
    
    $query .= " ORDER BY da.date DESC, da.appointment_time DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $appointments = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $appointments = [];
}

include 'includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="page-container">
            <h2 class="mb-4"><i class="fas fa-calendar-alt"></i> My Appointments</h2>
            
            <?php if ($message): ?>
                <div class="alert alert-info alert-dismissible fade show">
                    <i class="fas fa-info-circle"></i> <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <!-- Filter Buttons -->
            <div class="mb-4">
                <div class="btn-group" role="group">
                    <a href="?filter=all" class="btn <?php echo $filter == 'all' ? 'btn-primary' : 'btn-outline-primary'; ?>">
                        All
                    </a>
                    <a href="?filter=pending" class="btn <?php echo $filter == 'pending' ? 'btn-warning' : 'btn-outline-warning'; ?>">
                        Pending
                    </a>
                    <a href="?filter=approved" class="btn <?php echo $filter == 'approved' ? 'btn-success' : 'btn-outline-success'; ?>">
                        Approved
                    </a>
                    <a href="?filter=rejected" class="btn <?php echo $filter == 'rejected' ? 'btn-danger' : 'btn-outline-danger'; ?>">
                        Rejected
                    </a>
                    <a href="?filter=cancelled" class="btn <?php echo $filter == 'cancelled' ? 'btn-secondary' : 'btn-outline-secondary'; ?>">
                        Cancelled
                    </a>
                </div>
            </div>
            
            <!-- Appointments Table -->
            <div class="card">
                <div class="card-header">
                    <h5>
                        <i class="fas fa-list"></i> 
                        <?php echo ucfirst($filter); ?> Appointments (<?php echo count($appointments); ?>)
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (empty($appointments)): ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> No appointments found.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Patient Name</th>
                                        <th>Contact</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Fee</th>
                                        <th>Status</th>
                                        <th>Booked On</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($appointments as $apt): ?>
                                        <tr>
                                            <td><?php echo $apt['app_id']; ?></td>
                                            <td><?php echo htmlspecialchars($apt['patient_name']); ?></td>
                                            <td><?php echo htmlspecialchars($apt['patient_email']); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($apt['date'])); ?></td>
                                            <td><?php echo date('h:i A', strtotime($apt['appointment_time'])); ?></td>
                                            <td>₹<?php echo $apt['cost']; ?></td>
                                            <td>
                                                <?php
                                                $badge = '';
                                                switch($apt['status']) {
                                                    case 'approved': $badge = 'success'; break;
                                                    case 'pending': $badge = 'warning'; break;
                                                    case 'rejected': $badge = 'danger'; break;
                                                    case 'cancelled': $badge = 'secondary'; break;
                                                }
                                                ?>
                                                <span class="badge bg-<?php echo $badge; ?>">
                                                    <?php echo ucfirst($apt['status']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($apt['created_at'])); ?></td>
                                            <td>
                                                <?php if ($apt['status'] == 'pending'): ?>
                                                    <a href="?action=approve&app_id=<?php echo $apt['app_id']; ?>&filter=<?php echo $filter; ?>" 
                                                       class="btn btn-success btn-sm"
                                                       onclick="return confirm('Approve this appointment?')">
                                                        <i class="fas fa-check"></i>
                                                    </a>
                                                    <a href="?action=reject&app_id=<?php echo $apt['app_id']; ?>&filter=<?php echo $filter; ?>" 
                                                       class="btn btn-danger btn-sm"
                                                       onclick="return confirm('Reject this appointment?')">
                                                        <i class="fas fa-times"></i>
                                                    </a>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
