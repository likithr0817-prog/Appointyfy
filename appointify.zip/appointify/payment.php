<?php
/**
 * Appointify - Payment/Booking Summary Page
 * Confirm appointment details before booking
 */
session_start();
require_once 'connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 3) {
    header('Location: login.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header('Location: search.php');
    exit();
}

$doctor_id = (int)$_POST['doctor_id'];
$date = $_POST['date'];
$time = $_POST['time'];
$reason = trim($_POST['reason'] ?? '');

// Get doctor details
try {
    $stmt = $pdo->prepare("SELECT * FROM doctor WHERE IndexNumber = ? AND approval_status = 'approved'");
    $stmt->execute([$doctor_id]);
    $doctor = $stmt->fetch();
    
    if (!$doctor) {
        header('Location: search.php');
        exit();
    }
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
}

include 'includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="page-container" style="max-width: 700px; margin: 0 auto;">
            <h2 class="text-center mb-4">
                <i class="fas fa-file-invoice"></i> Appointment Summary
            </h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5><i class="fas fa-user-md"></i> Doctor Information</h5>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <td width="40%"><strong>Doctor Name:</strong></td>
                            <td><?php echo htmlspecialchars($doctor['Name']); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Specialty:</strong></td>
                            <td><?php echo htmlspecialchars($doctor['Speciality']); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Hospital:</strong></td>
                            <td><?php echo htmlspecialchars($doctor['Hospital']); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Location:</strong></td>
                            <td><?php echo htmlspecialchars($doctor['ChamberLocation']); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5><i class="fas fa-calendar-check"></i> Appointment Details</h5>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <td width="40%"><strong>Patient Name:</strong></td>
                            <td><?php echo htmlspecialchars($_SESSION['user_name']); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Appointment Date:</strong></td>
                            <td><?php echo date('l, F j, Y', strtotime($date)); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Appointment Time:</strong></td>
                            <td><?php echo date('h:i A', strtotime($time)); ?></td>
                        </tr>
                        <?php if ($reason): ?>
                        <tr>
                            <td><strong>Reason for Visit:</strong></td>
                            <td><?php echo htmlspecialchars($reason); ?></td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5><i class="fas fa-rupee-sign"></i> Fee Details</h5>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <td><strong>Consultation Fee:</strong></td>
                            <td class="text-end"><h5 class="mb-0">₹<?php echo htmlspecialchars($doctor['VisitCharge']); ?></h5></td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <form method="POST" action="payment_success.php">
                <input type="hidden" name="doctor_id" value="<?php echo $doctor_id; ?>">
                <input type="hidden" name="date" value="<?php echo htmlspecialchars($date); ?>">
                <input type="hidden" name="time" value="<?php echo htmlspecialchars($time); ?>">
                <input type="hidden" name="cost" value="<?php echo $doctor['VisitCharge']; ?>">
                
                <div class="alert alert-warning">
                    <i class="fas fa-info-circle"></i>
                    <strong>Note:</strong> By confirming this appointment, you agree to visit the doctor at the scheduled time. 
                    Please arrive 10 minutes early.
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-success btn-lg">
                        <i class="fas fa-check-circle"></i> Confirm & Book Appointment
                    </button>
                    <a href="appointment.php?doctor_id=<?php echo $doctor_id; ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Edit
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
