<?php
/**
 * Appointify - Logout Script
 * Destroy session and redirect to login
 */
session_start();
session_unset();
session_destroy();
header('Location: login.php?logout=1');
exit();
?>
