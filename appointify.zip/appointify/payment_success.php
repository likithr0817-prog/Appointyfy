<?php
/**
 * Appointify - Payment Success Page
 * Insert appointment into database
 */
session_start();
require_once 'connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 3) {
    header('Location: login.php');
    exit();
}

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $doctor_id = (int)$_POST['doctor_id'];
    $user_id = $_SESSION['user_id'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $cost = (float)$_POST['cost'];
    
    try {
        // Check if appointment slot is already taken
        $stmt = $pdo->prepare("SELECT * FROM doctor_availablity WHERE doc_id = ? AND date = ? AND appointment_time = ?");
        $stmt->execute([$doctor_id, $date, $time]);
        
        if ($stmt->fetch()) {
            $error = 'This time slot is already booked. Please choose a different time.';
        } else {
            // Insert appointment
            $stmt = $pdo->prepare("INSERT INTO doctor_availablity (doc_id, user_id, appointment_time, date, cost, status) 
                                  VALUES (?, ?, ?, ?, ?, 'pending')");
            $stmt->execute([$doctor_id, $user_id, $time, $date, $cost]);
            $success = true;
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
} else {
    header('Location: search.php');
    exit();
}

include 'includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="page-container" style="max-width: 600px; margin: 0 auto;">
            <?php if ($success): ?>
                <div class="text-center">
                    <div class="mb-4">
                        <i class="fas fa-check-circle fa-5x text-success"></i>
                    </div>
                    <h2 class="text-success mb-3">Appointment Booked Successfully!</h2>
                    <div class="alert alert-success">
                        <h5><i class="fas fa-info-circle"></i> Appointment Details</h5>
                        <p class="mb-1"><strong>Date:</strong> <?php echo date('l, F j, Y', strtotime($date)); ?></p>
                        <p class="mb-1"><strong>Time:</strong> <?php echo date('h:i A', strtotime($time)); ?></p>
                        <p class="mb-0"><strong>Status:</strong> <span class="badge bg-warning">Pending Doctor Approval</span></p>
                    </div>
                    <p class="mb-4">
                        Your appointment has been submitted successfully. The doctor will review and confirm your appointment shortly.
                        You will be able to see the status in your profile.
                    </p>
                    <div class="d-grid gap-2">
                        <a href="profile.php" class="btn btn-primary btn-lg">
                            <i class="fas fa-user-circle"></i> View My Appointments
                        </a>
                        <a href="search.php" class="btn btn-outline-secondary">
                            <i class="fas fa-search"></i> Book Another Appointment
                        </a>
                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="fas fa-home"></i> Go to Home
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <div class="text-center">
                    <div class="mb-4">
                        <i class="fas fa-exclamation-triangle fa-5x text-danger"></i>
                    </div>
                    <h2 class="text-danger mb-3">Booking Failed</h2>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                    </div>
                    <a href="search.php" class="btn btn-primary">
                        <i class="fas fa-arrow-left"></i> Back to Search
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
