# APPOINTIFY - QUICK INSTALLATION GUIDE

## 🚀 Quick Setup (5 Minutes)

### Step 1: Install XAMPP
1. Download XAMPP from: https://www.apachefriends.org
2. Install and start Apache + MySQL services

### Step 2: Create Database
1. Open phpMyAdmin: http://localhost/phpmyadmin
2. Click "SQL" tab
3. Copy all content from `database.sql` file
4. Click "Go" button
5. Database `teledoc` will be created with sample data

### Step 3: Deploy Files
1. Copy the `appointify` folder
2. Paste in: `C:\xampp\htdocs\` (Windows) or `/Applications/XAMPP/htdocs/` (Mac)

### Step 4: Access Application
Open browser and go to: http://localhost/appointify

---

## 🔑 DEFAULT LOGIN CREDENTIALS

### ADMIN
- Email: admin@appointify.com
- Password: admin123

### DOCTOR (Sample)
- Email: rajesh.kumar@hospital.com
- Password: doc123

### PATIENT
- Register new account from registration page

---

## 📁 PROJECT STRUCTURE

```
appointify/
├── admin/              # Admin panel files
├── assets/             # CSS, JS, Images
├── includes/           # Navbar and common includes
├── connection.php      # Database configuration
├── database.sql        # SQL schema and data
├── index.php          # Home page
├── login.php          # Login page
├── register.php       # Registration page
├── search.php         # Doctor search
├── appointment.php    # Booking page
├── profile.php        # Patient profile
├── doctor_*.php       # Doctor module files
└── README.md          # Complete documentation
```

---

## ✅ VERIFICATION CHECKLIST

After installation, verify:
- [ ] Apache and MySQL are running in XAMPP
- [ ] Database `teledoc` exists with 4 tables
- [ ] Home page loads at http://localhost/appointify
- [ ] Can login with admin credentials
- [ ] Can register new patient account
- [ ] Can search and view doctors
- [ ] Admin can manage doctors and appointments

---

## 🐛 COMMON ISSUES & SOLUTIONS

**Issue:** "Database connection failed"
**Fix:** Start MySQL in XAMPP, check connection.php credentials

**Issue:** "Page not found"
**Fix:** Ensure folder is in htdocs, Apache is running

**Issue:** "Cannot login"
**Fix:** Verify database is created, check credentials

**Issue:** "Blank page"
**Fix:** Enable PHP error display, check error logs

---

## 🎯 KEY FEATURES

✅ Patient registration and appointment booking
✅ Doctor profile management and availability
✅ Admin panel with full system control
✅ Appointment approval workflow
✅ Search by specialty and location
✅ Modern responsive design
✅ Secure authentication and sessions
✅ Role-based access control

---

## 📊 DATABASE TABLES

1. **info** - User authentication (Admin, Doctor, Patient)
2. **doctor** - Doctor profiles and details
3. **doctor_availablity** - Appointment records
4. **feedback** - Patient feedback (optional)

---

## 🔐 SECURITY FEATURES

✅ PDO prepared statements (SQL injection prevention)
✅ Session-based authentication
✅ Password protection
✅ Input validation
✅ Role-based access control
✅ Secure database connections

---

## 📱 RESPONSIVE DESIGN

✅ Desktop (1920px+)
✅ Laptop (1366px - 1920px)
✅ Tablet (768px - 1366px)
✅ Mobile (320px - 768px)

---

## 🎓 PROJECT INFORMATION

- **Type:** BCA Mini Project
- **Category:** Healthcare Management System
- **Technology:** PHP, MySQL, Bootstrap, JavaScript
- **Architecture:** 3-Tier (Presentation, Application, Data)

---

## 📞 SUPPORT

For issues or questions:
- Check README.md for detailed documentation
- Review database.sql for schema details
- Verify XAMPP services are running
- Check PHP error logs in xampp/apache/logs/

---

## ⚡ QUICK TIPS

1. Always start Apache and MySQL before accessing
2. Use Chrome/Firefox for best experience
3. Clear browser cache if CSS doesn't load
4. Check console for JavaScript errors
5. Verify file permissions if upload issues occur

---

**Ready to use! Start exploring Appointify now! 🎉**

Access: http://localhost/appointify
Login: admin@appointify.com / admin123
