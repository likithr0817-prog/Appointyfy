-- Appointify Database Schema
-- Create Database
CREATE DATABASE IF NOT EXISTS teledoc CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE teledoc;

-- TABLE 1: info (User Authentication Table)
CREATE TABLE IF NOT EXISTS info (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(30) NOT NULL,
    email VARCHAR(30) NOT NULL UNIQUE,
    pass VARCHAR(16) NOT NULL,
    user_type INT NOT NULL COMMENT 'Admin=1, Doctor=2, Patient=3',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABLE 2: doctor (Doctor Profile Table)
CREATE TABLE IF NOT EXISTS doctor (
    IndexNumber INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(30),
    Email VARCHAR(30) UNIQUE,
    Password VARCHAR(16),
    Degree VARCHAR(40),
    Speciality VARCHAR(30),
    Division VARCHAR(50) COMMENT 'Area/Location',
    ChamberNumber VARCHAR(20),
    Hospital VARCHAR(50),
    ChamberLocation VARCHAR(50),
    TimeStart TIME,
    TimeEnd TIME,
    VisitCharge INT,
    approval_status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABLE 3: doctor_availablity (Appointments Table)
CREATE TABLE IF NOT EXISTS doctor_availablity (
    app_id INT PRIMARY KEY AUTO_INCREMENT,
    doc_id INT NOT NULL,
    user_id INT NOT NULL,
    appointment_time TIME,
    date DATE,
    cost DOUBLE,
    status ENUM('pending', 'approved', 'rejected', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doc_id) REFERENCES doctor(IndexNumber) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES info(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABLE 4: feedback (Optional - for patient feedback)
CREATE TABLE IF NOT EXISTS feedback (
    feedback_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    doc_id INT NOT NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    comments TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES info(id) ON DELETE CASCADE,
    FOREIGN KEY (doc_id) REFERENCES doctor(IndexNumber) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default admin account
-- Username: admin@appointify.com
-- Password: admin123
INSERT INTO info (name, email, pass, user_type) 
VALUES ('Admin', 'admin@appointify.com', 'admin123', 1)
ON DUPLICATE KEY UPDATE name=name;

-- Insert sample doctors (approved)
INSERT INTO doctor (Name, Email, Password, Degree, Speciality, Division, ChamberNumber, Hospital, ChamberLocation, TimeStart, TimeEnd, VisitCharge, approval_status)
VALUES 
('Dr. Rajesh Kumar', 'rajesh.kumar@hospital.com', 'doc123', 'MBBS, MD', 'Cardiologist', 'Bangalore', '201', 'Apollo Hospital', 'Koramangala', '09:00:00', '17:00:00', 800, 'approved'),
('Dr. Priya Sharma', 'priya.sharma@hospital.com', 'doc123', 'MBBS, MS', 'Dermatologist', 'Mysuru', '105', 'Manipal Hospital', 'Kuvempunagar', '10:00:00', '18:00:00', 600, 'approved'),
('Dr. Amit Patel', 'amit.patel@hospital.com', 'doc123', 'MBBS, DNB', 'Orthopedic', 'Bangalore', '302', 'Fortis Hospital', 'Bannerghatta Road', '08:00:00', '16:00:00', 900, 'approved')
ON DUPLICATE KEY UPDATE Name=Name;

-- Insert corresponding info records for doctors
INSERT INTO info (name, email, pass, user_type)
VALUES 
('Dr. Rajesh Kumar', 'rajesh.kumar@hospital.com', 'doc123', 2),
('Dr. Priya Sharma', 'priya.sharma@hospital.com', 'doc123', 2),
('Dr. Amit Patel', 'amit.patel@hospital.com', 'doc123', 2)
ON DUPLICATE KEY UPDATE name=name;
