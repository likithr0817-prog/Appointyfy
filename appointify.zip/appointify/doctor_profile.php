<?php
/**
 * Appointify - Doctor Profile Management
 * Update doctor profile information
 */
session_start();
require_once 'connection.php';

// Check if user is logged in as doctor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 2) {
    header('Location: login.php');
    exit();
}

$email = $_SESSION['user_email'];
$message = '';
$error = '';

// Get doctor info
try {
    $stmt = $pdo->prepare("SELECT * FROM doctor WHERE Email = ?");
    $stmt->execute([$email]);
    $doctor = $stmt->fetch();
    
    if (!$doctor) {
        header('Location: logout.php');
        exit();
    }
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $degree = trim($_POST['degree']);
    $speciality = trim($_POST['speciality']);
    $division = trim($_POST['division']);
    $hospital = trim($_POST['hospital']);
    $chamber_number = trim($_POST['chamber_number']);
    $chamber_location = trim($_POST['chamber_location']);
    $time_start = $_POST['time_start'];
    $time_end = $_POST['time_end'];
    $visit_charge = (int)$_POST['visit_charge'];
    
    try {
        $stmt = $pdo->prepare("
            UPDATE doctor SET 
            Name = ?, Degree = ?, Speciality = ?, Division = ?, 
            Hospital = ?, ChamberNumber = ?, ChamberLocation = ?,
            TimeStart = ?, TimeEnd = ?, VisitCharge = ?
            WHERE Email = ?
        ");
        $stmt->execute([
            $name, $degree, $speciality, $division,
            $hospital, $chamber_number, $chamber_location,
            $time_start, $time_end, $visit_charge, $email
        ]);
        
        // Update name in info table too
        $stmt = $pdo->prepare("UPDATE info SET name = ? WHERE email = ?");
        $stmt->execute([$name, $email]);
        
        $_SESSION['user_name'] = $name;
        
        $message = 'Profile updated successfully!';
        
        // Refresh doctor data
        $stmt = $pdo->prepare("SELECT * FROM doctor WHERE Email = ?");
        $stmt->execute([$email]);
        $doctor = $stmt->fetch();
        
    } catch (PDOException $e) {
        $error = 'Error updating profile: ' . $e->getMessage();
    }
}

include 'includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="page-container" style="max-width: 900px; margin: 0 auto;">
            <h2 class="mb-4"><i class="fas fa-user-circle"></i> My Profile</h2>
            
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($doctor['approval_status'] == 'pending'): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-clock"></i> Your profile is pending admin approval.
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h5><i class="fas fa-edit"></i> Update Profile Information</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="name" class="form-label">
                                    <i class="fas fa-user"></i> Full Name *
                                </label>
                                <input type="text" class="form-control" id="name" name="name" 
                                       value="<?php echo htmlspecialchars($doctor['Name'] ?? ''); ?>" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">
                                    <i class="fas fa-envelope"></i> Email
                                </label>
                                <input type="email" class="form-control" id="email" 
                                       value="<?php echo htmlspecialchars($doctor['Email']); ?>" readonly>
                                <small class="text-muted">Email cannot be changed</small>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="degree" class="form-label">
                                    <i class="fas fa-graduation-cap"></i> Degree/Qualification *
                                </label>
                                <input type="text" class="form-control" id="degree" name="degree" 
                                       value="<?php echo htmlspecialchars($doctor['Degree'] ?? ''); ?>" 
                                       placeholder="e.g., MBBS, MD" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="speciality" class="form-label">
                                    <i class="fas fa-stethoscope"></i> Specialization *
                                </label>
                                <input type="text" class="form-control" id="speciality" name="speciality" 
                                       value="<?php echo htmlspecialchars($doctor['Speciality'] ?? ''); ?>" 
                                       placeholder="e.g., Cardiologist" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="hospital" class="form-label">
                                    <i class="fas fa-hospital"></i> Hospital/Clinic Name *
                                </label>
                                <input type="text" class="form-control" id="hospital" name="hospital" 
                                       value="<?php echo htmlspecialchars($doctor['Hospital'] ?? ''); ?>" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="division" class="form-label">
                                    <i class="fas fa-map-marked-alt"></i> Division/Area *
                                </label>
                                <input type="text" class="form-control" id="division" name="division" 
                                       value="<?php echo htmlspecialchars($doctor['Division'] ?? ''); ?>" 
                                       placeholder="e.g., Bangalore, Mysuru" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="chamber_number" class="form-label">
                                    <i class="fas fa-door-open"></i> Chamber/Room Number
                                </label>
                                <input type="text" class="form-control" id="chamber_number" name="chamber_number" 
                                       value="<?php echo htmlspecialchars($doctor['ChamberNumber'] ?? ''); ?>" 
                                       placeholder="e.g., 101, A-25">
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="chamber_location" class="form-label">
                                    <i class="fas fa-map-marker-alt"></i> Chamber Location *
                                </label>
                                <input type="text" class="form-control" id="chamber_location" name="chamber_location" 
                                       value="<?php echo htmlspecialchars($doctor['ChamberLocation'] ?? ''); ?>" 
                                       placeholder="e.g., Koramangala, MG Road" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="time_start" class="form-label">
                                    <i class="fas fa-clock"></i> Available From *
                                </label>
                                <input type="time" class="form-control" id="time_start" name="time_start" 
                                       value="<?php echo $doctor['TimeStart'] ?? ''; ?>" required>
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label for="time_end" class="form-label">
                                    <i class="fas fa-clock"></i> Available Till *
                                </label>
                                <input type="time" class="form-control" id="time_end" name="time_end" 
                                       value="<?php echo $doctor['TimeEnd'] ?? ''; ?>" required>
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label for="visit_charge" class="form-label">
                                    <i class="fas fa-rupee-sign"></i> Consultation Fee (₹) *
                                </label>
                                <input type="number" class="form-control" id="visit_charge" name="visit_charge" 
                                       value="<?php echo $doctor['VisitCharge'] ?? ''; ?>" 
                                       min="0" required>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Update Profile
                            </button>
                            <a href="doctor_dashboard.php" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left"></i> Back to Dashboard
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
