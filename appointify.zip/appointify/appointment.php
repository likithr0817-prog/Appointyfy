<?php
/**
 * Appointify - Appointment Booking Page
 * Book appointment with selected doctor
 */
session_start();
require_once 'connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 3) {
    header('Location: login.php');
    exit();
}

$error = '';
$doctor_id = isset($_GET['doctor_id']) ? (int)$_GET['doctor_id'] : 0;

if ($doctor_id == 0) {
    header('Location: search.php');
    exit();
}

// Get doctor details
try {
    $stmt = $pdo->prepare("SELECT * FROM doctor WHERE IndexNumber = ? AND approval_status = 'approved'");
    $stmt->execute([$doctor_id]);
    $doctor = $stmt->fetch();
    
    if (!$doctor) {
        header('Location: search.php');
        exit();
    }
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
}

include 'includes/navbar.php';
?>

<div class="content-container">
    <div class="container">
        <div class="page-container">
            <div class="row">
                <!-- Doctor Profile -->
                <div class="col-md-5">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-user-md"></i> Doctor Profile</h5>
                        </div>
                        <div class="card-body">
                            <div class="text-center mb-3">
                                <div class="doctor-avatar mx-auto" style="width: 100px; height: 100px; font-size: 3rem;">
                                    <?php echo strtoupper(substr($doctor['Name'], 0, 1)); ?>
                                </div>
                            </div>
                            
                            <h4 class="text-center mb-3"><?php echo htmlspecialchars($doctor['Name']); ?></h4>
                            
                            <table class="table table-borderless">
                                <tr>
                                    <td><i class="fas fa-graduation-cap text-primary"></i> <strong>Degree:</strong></td>
                                    <td><?php echo htmlspecialchars($doctor['Degree'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td><i class="fas fa-stethoscope text-success"></i> <strong>Specialty:</strong></td>
                                    <td><?php echo htmlspecialchars($doctor['Speciality'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td><i class="fas fa-hospital text-danger"></i> <strong>Hospital:</strong></td>
                                    <td><?php echo htmlspecialchars($doctor['Hospital'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td><i class="fas fa-door-open text-info"></i> <strong>Chamber:</strong></td>
                                    <td><?php echo htmlspecialchars($doctor['ChamberNumber'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td><i class="fas fa-map-marker-alt text-warning"></i> <strong>Location:</strong></td>
                                    <td><?php echo htmlspecialchars($doctor['ChamberLocation'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td><i class="fas fa-map-marked-alt text-secondary"></i> <strong>Division:</strong></td>
                                    <td><?php echo htmlspecialchars($doctor['Division'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td><i class="fas fa-clock text-primary"></i> <strong>Timing:</strong></td>
                                    <td>
                                        <?php 
                                        if ($doctor['TimeStart'] && $doctor['TimeEnd']) {
                                            echo date('h:i A', strtotime($doctor['TimeStart'])) . ' - ' . 
                                                 date('h:i A', strtotime($doctor['TimeEnd']));
                                        } else {
                                            echo 'Not specified';
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td><i class="fas fa-rupee-sign text-success"></i> <strong>Fee:</strong></td>
                                    <td><h5 class="text-success mb-0">₹<?php echo htmlspecialchars($doctor['VisitCharge'] ?? '0'); ?></h5></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Booking Form -->
                <div class="col-md-7">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-calendar-plus"></i> Book Appointment</h5>
                        </div>
                        <div class="card-body">
                            <?php if ($error): ?>
                                <div class="alert alert-danger">
                                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                                </div>
                            <?php endif; ?>
                            
                            <form method="POST" action="payment.php">
                                <input type="hidden" name="doctor_id" value="<?php echo $doctor_id; ?>">
                                
                                <div class="mb-3">
                                    <label for="patient_name" class="form-label">
                                        <i class="fas fa-user"></i> Patient Name
                                    </label>
                                    <input type="text" class="form-control" id="patient_name" name="patient_name" 
                                           value="<?php echo htmlspecialchars($_SESSION['user_name']); ?>" readonly>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="date" class="form-label">
                                        <i class="fas fa-calendar"></i> Appointment Date
                                    </label>
                                    <input type="date" class="form-control" id="date" name="date" 
                                           min="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="time" class="form-label">
                                        <i class="fas fa-clock"></i> Appointment Time
                                    </label>
                                    <input type="time" class="form-control" id="time" name="time" required>
                                    <?php if ($doctor['TimeStart'] && $doctor['TimeEnd']): ?>
                                        <small class="text-muted">
                                            Doctor available: <?php echo date('h:i A', strtotime($doctor['TimeStart'])); ?> 
                                            - <?php echo date('h:i A', strtotime($doctor['TimeEnd'])); ?>
                                        </small>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="reason" class="form-label">
                                        <i class="fas fa-comment-medical"></i> Reason for Visit (Optional)
                                    </label>
                                    <textarea class="form-control" id="reason" name="reason" rows="3" 
                                              placeholder="Brief description of your health concern"></textarea>
                                </div>
                                
                                <div class="alert alert-info">
                                    <h6><i class="fas fa-info-circle"></i> Appointment Summary</h6>
                                    <p class="mb-1"><strong>Doctor:</strong> <?php echo htmlspecialchars($doctor['Name']); ?></p>
                                    <p class="mb-1"><strong>Consultation Fee:</strong> ₹<?php echo htmlspecialchars($doctor['VisitCharge']); ?></p>
                                    <p class="mb-0"><small class="text-muted">You will be redirected to confirm your appointment</small></p>
                                </div>
                                
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-arrow-right"></i> Proceed to Confirm
                                </button>
                            </form>
                            
                            <div class="mt-3 text-center">
                                <a href="search.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Search
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Set minimum time based on doctor's availability
document.addEventListener('DOMContentLoaded', function() {
    const timeInput = document.getElementById('time');
    const dateInput = document.getElementById('date');
    
    // Validate time is within doctor's availability
    timeInput.addEventListener('change', function() {
        const selectedTime = this.value;
        const startTime = '<?php echo $doctor['TimeStart'] ?? '00:00:00'; ?>';
        const endTime = '<?php echo $doctor['TimeEnd'] ?? '23:59:59'; ?>';
        
        if (selectedTime < startTime.substring(0, 5) || selectedTime > endTime.substring(0, 5)) {
            alert('Please select a time within doctor\'s availability: ' + 
                  startTime.substring(0, 5) + ' - ' + endTime.substring(0, 5));
            this.value = '';
        }
    });
});
</script>

</body>
</html>
